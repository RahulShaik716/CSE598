import smtplib
import docx
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication

def read_email_list(filename):
    with open(filename, 'r') as file:
        email_list = [line.strip() for line in file if line.strip()]
    return email_list

def send_email(subject, message, sender_email, sender_password, receiver_email, attachments=None):
    try:
        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = receiver_email
        msg['Subject'] = subject
        msg.attach(MIMEText(message, 'plain'))

        if attachments:
            for attachment in attachments:
                with open(attachment, "rb") as file:
                    part = MIMEApplication(file.read(), Name=attachment)
                part['Content-Disposition'] = f'attachment; filename="{attachment}"'
                msg.attach(part)

        with smtplib.SMTP_SSL('smtp.gamail.com', 535) as server:
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, receiver_email, msg.as_string())

        print(f"Email sent to {receiver_email}")
    except Exception as e:
        print(f"Failed to send email to {receiver_email}. Error: {e}")


def read_text_from_word_file(file_path):
    try:
        doc = docx.Document(file_path)
        full_text = []
        for para in doc.paragraphs:
            full_text.append(para.text)
        return '\n'.join(full_text)
    except Exception as e:
        print(f"Failed to read the Word document. Error: {e}")
        return None

if __name__ == "__main__":
    # Replace the following variables with your actual values
    word_file_path = r"C:\Users\Rahul\OneDrive - Arizona State University\Desktop\Respected Professor.docx"
    email_list_file = r"C:\Users\Rahul\OneDrive - Arizona State University\Desktop\TA DOCS\email_list.txt"
    sender_email = "dadarahulshaik@gmail.com"
    sender_password = "Jameeulla@1"
    subject = " Inquiry for Part-Time Teaching Assistant or Grader Position at ASU Computer Science Department"
    message = read_text_from_word_file(word_file_path)
    attachments = [r"C:\Users\Rahul\OneDrive - Arizona State University\Desktop\TA DOCS\gre.pdf", r"C:\Users\Rahul\OneDrive - Arizona State University\Desktop\TA DOCS\ielts.pdf"
                   ,r"C:\Users\Rahul\OneDrive - Arizona State University\Desktop\TA DOCS\marksmemo.pdf",r"C:\Users\Rahul\OneDrive - Arizona State University\Desktop\TA DOCS\resume1.pdf"
                   ,r"C:\Users\Rahul\OneDrive - Arizona State University\Desktop\TA DOCS\SSR_TSRPT.pdf"]  # Add the filenames of the attachments here

    email_list = read_email_list(email_list_file)
    for receiver_email in email_list:
        send_email(subject, message, sender_email, sender_password, receiver_email, attachments=attachments)
